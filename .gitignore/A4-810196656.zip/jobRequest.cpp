#include "jobRequest.hpp"

JobRequest::JobRequest(std::string _companyId, std::string _title, std::map<std::string, float> _conditions)
{
	companyId= _companyId;
	title= _title;
	conditions= _conditions;
}

bool JobRequest::canApply(User* user)
{
	for(auto condition:conditions)
		if( (user->getRate(condition.first)) <condition.second)
			return 0;
	return 1;
}

void JobRequest::applyForJob(User* user)
{
	if( !canApply(user) )
		return;
	appliedUsers.push_back(user);
}

float JobRequest::totalRate(int index)
{
	float totalRate= 0;
	User* user= appliedUsers[index];
	for(auto condition:conditions)
		totalRate+= (user->getRate(condition.first));
	return totalRate;
}

bool JobRequest::hireBestApplicant(std::string startsAt)
{
	if( appliedUsers.empty() )
		return 0;
	int index= 0;
	for(int i=1; i<appliedUsers.size(); i++)
		if( totalRate(i)>totalRate(index) )
			index=i;
	User* user= appliedUsers[index];
	user->addExperience(new Experience(user->getFirstName(), user->getLastName(), companyId, title, startsAt, NOW));
}

void JobRequest::print()
{
	std::cout << title << " in " << companyId << " - needed skills: ";
	bool first=1;
	for(auto condition:conditions)
	{
		if( !first )
			std::cout << " , ";
		std::cout << condition.first << " " << condition.second;
		first=0;
	}
}