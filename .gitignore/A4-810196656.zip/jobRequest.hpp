#ifndef __JOBREQUEST_H__
#define __JOBREQUEST_H__
#define NOW "INDIFINITE_DATE"

#include "user.hpp"

class JobRequest{
    public:
    	JobRequest(std::string _companyId, std::string _title, std::map<std::string, float> _conditions);
    	std::string getTitle(){ return title;}
    	std::string getCompanyName(){ return companyId; }
    	void applyForJob(User* user);
    	bool hireBestApplicant(std::string startsAt);
    	float totalRate(int index);
    	bool canApply(User* user);
    	void print();
    private:
        std::string companyId, title;
        std::map<std::string, float> conditions;
        std::vector<User*> appliedUsers;
};

#endif