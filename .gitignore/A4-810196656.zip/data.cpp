#include"data.hpp"

void Data::addUser(std::string firstName, std::string lastName, std::string emailAddress, std::string biography)
{
	User* user = new User(firstName, lastName, emailAddress, biography);
	if( findUserIndex(emailAddress)!=-1 )
		return;
	users.push_back(user);
}

void Data::addCompany(std::string name, std::string address, std::string description)
{
	Company* company= new Company(name, address, description);
	if(findCompanyIndex(name) !=-1)
		return;
	companies.push_back(company);
}

int Data::findUserIndex(std::string userId)
{
	for(int i=0; i<users.size(); i++)
		if( users[i]->isEqual(userId) )
			return i;
	return -1;
}
int Data::findCompanyIndex(std::string companyId)
{
	for(int i=0; i<companies.size(); i++)
		if( companies[i]->isEqual(companyId) )
			return i;
	return -1;
}

void Data::addExperience(std::string userId, std::string companyId, std::string title, std::string startAt , std::string endsAt)
{
 	int userIndex= findUserIndex(userId);
 	if( userIndex==-1 )
 		return;
 	int companyIndex= findCompanyIndex(companyId);
 	if( companyIndex==-1 )
 		return;
 	Experience* experience= new Experience(users[userIndex]->getFirstName(), users[userIndex]->getLastName(), companyId, title, startAt, endsAt);
 	users[userIndex]->addExperience(experience);
 	companies[companyIndex]->addExperience(experience);
}

void Data::assignSkill(std::string userId, std::string skillName)
{
	int userIndex= findUserIndex(userId);
 	if( userIndex==-1 )
 		return;
 	users[userIndex]->addSkill(skillName);
}

void Data::endorseSkill(std::string endorserUserId, std::string skilledUserId, std::string skillName)
{
	int endorserIndex= findUserIndex(endorserUserId);
	int skilledIndex= findUserIndex(skilledUserId);
	if( endorserIndex==-1 || skilledIndex==-1 )
		return;
	users[skilledIndex]->addEndorser(skillName, users[endorserIndex]);
}

void Data::follow(std::string followerId, std::string followingId)
{
	int followerIndex= findUserIndex(followerId);
	int followingIndex= findUserIndex(followingId);
	if( followingIndex==-1 || followerIndex==-1 )
	 	return;
	users[followerIndex]->addFriend(users[followingIndex]);
	users[followingIndex]->addFriend(users[followerIndex]);
}

void Data::printUserProfile(std::string userId)
{
	int userIndex= findUserIndex(userId);
	if( userIndex==-1 )
		return;
	users[userIndex]->printProfile();
}

void Data::printCompanyProfile(std::string companyName)
{
	int companyIndex= findCompanyIndex(companyName);
	if( companyIndex==-1 )
		return;
	companies[companyIndex]->printProfile();
}

void Data::printNetwork(std::string userId, int level)
{
	int userIndex= findUserIndex(userId);
	if( userIndex==-1 )
		return;
	users[userIndex]->printNetwork(level);
}

int Data::findJobIndex(std::string companyName, std::string title)
{
	for(int i=0; i<jobRequests.size(); i++)
		if( jobRequests[i]->getCompanyName()==companyName && jobRequests[i]->getTitle()==title )
			return i;
	return -1;
}

void Data::addJobRequest(std::string companyName, std::string title, std::map<std::string, float> conditions)
{
	int jobIndex=findJobIndex(companyName, title);
	if( jobIndex==-1 )
		return;
	int companyIndex= findCompanyIndex(companyName);
	if( companyIndex==-1 )
		return;
	JobRequest* jobRequest= new JobRequest(companyName, title, conditions);
	companies[companyIndex]->addJobRequest(jobRequest);
	jobRequests.push_back(jobRequest);
}

void Data::applyForJob(std::string userId, std::string companyId, std::string jobTitle)
{
	int jobIndex= findJobIndex(companyId, jobTitle);
	if( jobIndex==-1 )
		return;
	int userIndex= findUserIndex(userId);
	if( userIndex==-1 )
		return;
	jobRequests[jobIndex]->applyForJob(users[userIndex]);
}

void Data::hireBestApplicant(std::string companyId, std::string jobTitle, std::string startsAt)
{
	int jobIndex= findJobIndex(companyId, jobTitle);
	if( jobIndex==-1 )
		return;
	int companyIndex= findCompanyIndex(companyId);
	if( companyIndex==-1 )
		return;
	if( jobRequests[jobIndex]->hireBestApplicant(startsAt))
	{
		jobRequests.erase(jobRequests.begin()+jobIndex);
		companies[companyIndex]->removeJobRequest(jobTitle);
	}
}

void Data::printSuggestedJobs(std::string userId)
{	
	int userIndex= findUserIndex(userId);
	if( userIndex==-1 )
		return;
	User* user= users[userIndex];
	int count=1;
	for(auto jobRequest:jobRequests)
		if(jobRequest->canApply(user))
		{
			std::cout << count << ". ";
			jobRequest->print();
			count++;
		}
	std::cout << std::endl;
}

void Data::printSuggestedUsers(std::string companyName, std::string jobTitle)
{
	int jobIndex= findJobIndex(companyName, jobTitle);
	if( jobIndex==-1 )
		return;
	int count=1;
	for(User* user:users)
		if(jobRequests[jobIndex]->canApply(user))
		{
			std::cout << count << ".\n";
			count++;
			user->printProfile();
		}
}
