#include"user.hpp"
#include<iostream>
#include<string>


User::User(std::string _firstName, std::string _lastName, std::string _emailAddress, std::string _biography)
{
	firstName=_firstName;
	lastName=_lastName;
	emailAddress=_emailAddress;
	biography=_biography;
}

std::string User::getFirstName(){ return firstName; }
std::string User::getLastName(){ return lastName; }

bool User::isEqual(std::string _emailAddress){ return _emailAddress==emailAddress; }

float User::getRate(std::string skillName)
{
	int skillIndex= findSkillIndex(skillName);
	if( skillIndex==-1 )
		return -1;
	float skillRate=0;
	for(int i=0; i<endorsers[skillName].size(); i++)
		skillRate+= sqrt( endorsers[skillName][i]->getEndorserCount(skillName)+1 );
	return skillRate;
}

int User::getEndorserCount(std::string skillName)
{
	int skillIndex= findSkillIndex(skillName);
	if( skillIndex==-1 )
		return 0;
	return skills[skillIndex]->getEndorserCount();
}

void User::addEndorser(std::string skillName, User* user)
{
	if( findSkillIndex(skillName)==-1 )
		addSkill(skillName);
	for(int i=0; i<endorsers[skillName].size(); i++)
		if( endorsers[skillName][i]==user )
			return;
	skills[findSkillIndex(skillName)]->increaseCount();
	endorsers[skillName].push_back(user);
}

int User::findSkillIndex(std::string skillName)
{
	for(int i=0; i<skills.size(); i++)
		if( skills[i]->isEqual(skillName) )
			return i;
	return -1;
}

void User::addSkill(std::string skillName)
{
	if( findSkillIndex(skillName)!=-1 )
		return;
	skills.push_back(new Skill(skillName));
}
void User::addFriend(User* newFriend)
{
	for(int i=0; i<friends.size(); i++)
		if( friends[i]==newFriend )
			return;
	friends.push_back(newFriend);
}

void User::sortExperiences()
{
	for(int i=0; i<experiences.size(); i++)
		for(int j=0; j<(experiences.size()-1); j++)
			if( (experiences[j+1]->getDateSegment())->lessThan( experiences[j]->getDateSegment() ) )
				std::swap(experiences[j],experiences[j+1]);
}

void User::printProfile()
{
	std::cout << "Name: " << firstName << " " << lastName << std::endl;
	std::cout << "Email: " << emailAddress << std::endl;
	std::cout << "Biography: " << biography << std::endl;
	std::cout << "Network: " << (friends.size()) << " " << "connections\n";
	sortExperiences();
	std::cout << "Experiences:\n";
	for(int i=0; i<experiences.size(); i++)
	{
		std::cout << "\t" << (i+1) << ". ";
		( experiences[i]->getDateSegment() )->printSegment();
		std::cout << " " << (experiences[i]->getTitle()) << " at " << (experiences[i]->getCompanyId()) << std::endl;
	}
	std::cout << "Skills:\n";
	for(int i=0; i<skills.size(); i++)
	{
		std::cout << "\t" << (i+1) << ". ";
		std::cout << (skills[i]->getName()) << " - ";
		printFloat( getRate(skills[i]->getName()) );
		std::cout << std::endl;
	}
	std::cout << std::endl;
}

void User::printFloat(float number)
{
	number*= 100;
	number= int(number);
	int a= number;
	int b= a%100;
	a/= 100;
	if( b%10== 0 )
		b/=10;
	if( b==0 )
		std::cout << a;
	else
		std::cout << a << '.' << b;
}

void User::printNetwork(int level)
{
	std::map<User*, bool> mark;
	std::map<User*, int> distance;
	mark[this]= 1;
	distance[this]= 0;
	std::vector<User*> bfs;
	bfs.push_back(this);
	for(int i=0; i<bfs.size(); i++)
	{
		User* user= bfs[i];
		std::vector<User*> friends= user->friends;
		for(int j=0; j<friends.size(); j++)
			if( !mark[friends[j]] )
			{
				mark[friends[j]]= 1;
				distance[friends[j]]= 1+distance[user];
				bfs.push_back(friends[j]);
			}
	}
	int number= 1;
	for(int i=0; i<bfs.size(); i++)
	{
		User* user= bfs[i];
		if( distance[user]==level )
		{
			std::cout << number << ".\n";
			user->printProfile();
			number++;
		}
	}
}