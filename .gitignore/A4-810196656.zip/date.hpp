#ifndef __DATE_H__
#define __DATE_H__

#include <algorithm>
#include <sstream>
#include <iostream>

class Date{
    public:
    	Date(std::string date);
    	int getYear();
		int getMonth();
		int getDay();
		bool lessThan(Date* date);
		void printDate();
    private:
    	int day, month, year;
};

#endif