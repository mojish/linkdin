#ifndef __COMPANY_H__
#define __COMPANY_H__

#include "jobRequest.hpp"
#include "experience.hpp"
#include "user.hpp"

class Company{
    public:
    	Company(std::string _name, std::string _address, std::string _description);
    	bool isEqual(std::string _name);
    	void addExperience(Experience* experience);
    	std::string getName();
    	void printProfile();
    	void sortExperiences();
    	int findJobIndex(std::string title);
    	void addJobRequest(JobRequest* jobRequest);
    	void removeJobRequest(std::string jobTitle);
    private:
        std::string name, address, description;
        std::vector<JobRequest*> jobRequests;
        std::vector<Experience*> experiences;
};

#endif