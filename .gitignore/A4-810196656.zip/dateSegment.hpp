#ifndef __DATESEGMENT_H__
#define __DATESEGMENT_H__

#include "date.hpp"

class DateSegment{
    public:
    	DateSegment(Date* _startsAt, Date*_endsAt);
    	bool lessThan(DateSegment* dateSegment);
		Date* getStart();
		Date* getEnd();
		void printSegment();
    private:
    	Date* startsAt, *endsAt;
};

#endif