#ifndef __SKILL_H__
#define __SKILL_H__

#include <algorithm>
#include <sstream>
#include <iostream>
#include <vector>
#include <string>
#include <map>

class Skill{
    public:
    	Skill(std::string _skillName);
    	bool isEqual(std::string _skillName){ return skillName==_skillName; }
    	void increaseCount(){ endorserCount++; }
    	int getEndorserCount(){return endorserCount; }
    	std::string getName(){ return skillName;}
    private:
 		std::string skillName;
 		int endorserCount;
};

#endif