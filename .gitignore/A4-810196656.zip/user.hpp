#ifndef __USER_H__
#define __USER_H__

#include "skill.hpp"
#include "experience.hpp"

class User{
    public:
    	User(std::string _firstName, std::string _lastName, std::string _emailAddress, std::string _biography);
    	bool isEqual(std::string _emailAddress);
    	void addExperience(Experience* experience){ experiences.push_back(experience); }
    	float getRate(std::string skillName);
    	int getEndorserCount(std::string skillName);
    	void addEndorser(std::string skillName, User* user);
    	int findSkillIndex(std::string skillName);
    	void addSkill(std::string skillName);
    	void addFriend(User* newFriend);
    	void printProfile();
    	void sortExperiences();
        void printFloat(float number);
        std::string getFirstName();
        std::string getLastName();
        void printNetwork(int level);
    private:
        std::string firstName,lastName,emailAddress,biography;
        std::vector<Skill*> skills;
        std::vector<Experience*> experiences;
        std::map<std::string, std::vector<User*> >endorsers;
        std::vector<User*> friends;
};

#endif
