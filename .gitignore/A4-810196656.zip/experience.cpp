#include "experience.hpp"

Experience::Experience(std::string _userFirstName, std::string _userLastName, std::string _companyId, std::string _title, std::string startsAt, std::string endsAt)
{
	companyId= _companyId;
	title= _title;
	userLastName= _userLastName;
	userFirstName= _userFirstName;
	dateSegment= new DateSegment( new Date(startsAt), new Date(endsAt));
}
