#include "company.hpp"

Company::Company(std::string _name, std::string _address, std::string _description)
{
	name=_name;
	address=_address;
	description=_description;
}

void Company::addExperience(Experience* experience){ experiences.push_back(experience); }

void Company::addJobRequest(JobRequest* jobRequest){ jobRequests.push_back(jobRequest); }

std::string Company::getName(){ return name; }

bool Company::isEqual(std::string _name){ return _name==name; }

void Company::sortExperiences()
{
	for(int i=0; i<experiences.size(); i++)
		for(int j=0; j<(experiences.size()-1); j++)
			if( (experiences[j+1]->getDateSegment())->lessThan( experiences[j]->getDateSegment() ) )
				std::swap(experiences[j],experiences[j+1]);
}

void Company::printProfile()
{
	std::cout << "Name: " << name << std::endl;
	std::cout << "Address: " << address << std::endl;
	std::cout << "Description: " << description << std::endl;
	sortExperiences();
	std::cout << "Jobs:\n";
	for(int i=0; i<experiences.size(); i++)
	{
		std::cout << "\t" << (i+1) << ". ";
		( experiences[i]->getDateSegment() )->printSegment();
		std::cout << " " << (experiences[i]->getTitle()) << " by ";
		std::cout << (experiences[i]->getUserFirstName()) << " " << (experiences[i]->getUserLastName()) <<std::endl;
	}
	std::cout << "Requests:\n";
	for(int i=0; i<jobRequests.size(); i++)
	{
		std::cout << "\t" << (i+1) << ". ";
		jobRequests[i]->print();
	}
	std::cout << std::endl;
}

int Company::findJobIndex(std::string title)
{
	for(int i=0; i<jobRequests.size(); i++)
		if( jobRequests[i]->getTitle()==title )
			return i;
	return -1;
}
void Company::removeJobRequest(std::string jobTitle)
{
	int jobIndex= findJobIndex(jobTitle);
	jobRequests.erase(jobRequests.begin()+jobIndex);
}
