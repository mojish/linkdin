#include "dateSegment.hpp"

DateSegment::DateSegment(Date* _startsAt, Date* _endsAt)
{
	startsAt= _startsAt;
	endsAt= _endsAt;
}

Date* DateSegment::getStart(){ return startsAt; }
Date* DateSegment::getEnd(){ return endsAt; }

bool DateSegment::lessThan(DateSegment* dateSegment)
{
	if( startsAt->lessThan(dateSegment->getStart()) )
		return 1;
	if( dateSegment->lessThan(this) )
		return 0;
	if( endsAt->lessThan(dateSegment->getEnd()) )
		return 1;
	return 0;
}
void DateSegment::printSegment()
{
	startsAt->printDate();
	std::cout << " - ";
	endsAt->printDate();
}