#ifndef __EXPRIENCE_H__
#define __EXPRIENCE_H__

#include "dateSegment.hpp"

class Experience
{
    public:
    	Experience(std::string _userFirstName, std::string _userLastName, std::string companyId, std::string title, std::string startsAt, std::string endsAt);
    	DateSegment* getDateSegment(){ return dateSegment; }
    	std::string getTitle(){ return title; }
    	std::string getCompanyId(){ return companyId; }
    	std::string getUserFirstName(){ return userFirstName; }
    	std::string getUserLastName(){ return userLastName; }
    private:
    	std::string userFirstName, userLastName, companyId, title, startsAt, endsAt;
    	DateSegment* dateSegment; 
};

#endif
