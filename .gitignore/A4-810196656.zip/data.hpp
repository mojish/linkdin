#ifndef __DATA_H__
#define __DATA_H__

#include "user.hpp"
#include "company.hpp"
#include "jobRequest.hpp"
#include "experience.hpp"

class Data
{
    public:
        void addUser(std::string firstName, std::string lastName, std::string emailAddress, std::string biography);
        void addCompany(std::string name, std::string address, std::string description);
        int findUserIndex(std::string userId);
        int findCompanyIndex(std::string companyId);
        void addExperience(std::string userId, std::string companyId, std::string title, std::string startAt , std::string endsAt);
        void assignSkill(std::string userId, std::string skillName);
        void endorseSkill(std::string endorserUserId, std::string skilledUserId, std::string skillName);
        void follow(std::string followerId, std::string followingId);
        void printUserProfile(std::string userId);
        void printCompanyProfile(std::string companyName);
        void printNetwork(std::string userId, int level);
        int findJobIndex(std::string companyName, std::string title);
        void addJobRequest(std::string companyName, std::string title, std::map<std::string, float> conditions);
        void applyForJob(std::string userId, std::string companyId, std::string jobTitle);
        void hireBestApplicant(std::string companyId, std::string jobTitle, std::string startsAt);
        void printSuggestedJobs(std::string userId);
        void printSuggestedUsers(std::string companyName, std::string jobTitle);
    private:
        std::vector<User*> users;
        std::vector<Company*> companies;
        std::vector<JobRequest*> jobRequests;
};

#endif
