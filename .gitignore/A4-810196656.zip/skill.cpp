#include "skill.hpp"

Skill::Skill(std::string _skillName)
{
	skillName= _skillName;
	endorserCount=0;
}