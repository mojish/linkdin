#include "date.hpp"

Date::Date(std::string date)
{
	replace(date.begin(), date.end(), '/', ' ');
	std::stringstream _date;
	_date << date;
	if( !(_date >> day >> month >> year) )
		day = month = year = 0;
}

int Date::getYear(){ return year; }
int Date::getMonth(){ return month; }
int Date::getDay(){ return day; }

bool Date::lessThan(Date* date)
{
	if( month==0 )
		return 0;
	if(year < date->getYear())
		return 1;
	if(month < date->getMonth())
		return 1;
	if(day < date->getDay())
		return 1;
	return 0;
}

void Date::printDate()
{
	if( month==0 )
		std::cout << "NOW";
	else
		std::cout << day << "/" << month << "/" << year;
}